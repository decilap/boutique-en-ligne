INSERT INTO product (name, price, image) 
VALUES("Anthurium, pot D12cm", 17, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0952000/952438_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Anthurium: Pot Ø17cm petit modèle - Coloris variables", 19, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0077000/77390_010.jpg");
INSERT INTO product (name, price, image) 
VALUES("Anthurium elipticum 'Jungle Bush' pot déco foncé D24cm", 139, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910762_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Strelitzia Nicolai : D.21-H.75", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801427_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum 'Sweet Lauretta' Pot déco foncé D24cm", 84, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910744_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum 'Sweet Lauretta' Pot déco clair D24cm", 84, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910743_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum: d.14cm, pot grand modèle", 7, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0063000/63158_005.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum 'Sweet Lauretta' pot D24cm", 69, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910674_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Strelitzia Nicolai Cache-pot Anthracite: D.21-H.75", 64, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801429_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Strelitzia Nicolai Cache-pot Blanc : D.21-H.75", 64, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801428_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum 'Sweet Lauretta' cache-pot blanc D21cm", 52, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832922_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum 'Sweet Lauretta' pot D21 x H85cm", 47, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832920_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum Bingo Cupido cache-pot gris D17cm", 41, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832828_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Tillandsias 'Filles de l'air' - H.5-10 cm - Lot de 6", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1023000/1023071_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Oiseau de Paradis Strelitzia - pot ⌀21cm - H.100-120cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1029000/1029001_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Amaryllis, mix D17cm", 14, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0871000/871531_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Plantes fleuries : pot d.6cm - Coloris et variétés variables", 2, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0053000/53536_039.jpg");
INSERT INTO product (name, price, image) 
VALUES("Amaryllis Ti sento mix d14", 7, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0566000/566494_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kalanchoe : Ø10,5cm, pot - Coloris variables", 4, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0121000/121550_011.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum : d.17cm, pot petit modèle", 17, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0070000/70806_007.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bromeliacee Coupe céramique D16 cm - Coloris variables", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0476000/476212_006.jpg");
INSERT INTO product (name, price, image) 
VALUES("Azalée d'intérieur : plante Ø25cm pot - Coloris variables", 9, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0038000/38729_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Azalée d'intérieur : Ø35cm, pot - Coloris variables", 20, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0038000/38623_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Amaryllis : 2 boutons pot", 8, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0308000/308631_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Amaryllis rouge pot kraft Ø14 cm", 8, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0871000/871522_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Amaryllis : 2 boutons pot Ø13cm", 6, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0308000/308624_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Stephanotis floribunda 'Elegance' pot D 20 cm", 29, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951243_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Aeschynanthus : suspension Ø15cm", 19, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0369000/369214_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cyclamen persicum, diamètre 30 cm, hauteur 35 cm - Coloris variables", 8, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0496000/496007_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Azalée d'intérieur : H.60cm Pyramide - Coloris variables", 29, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0312000/312375_005.jpg");
INSERT INTO product (name, price, image) 
VALUES("Tillandsia : 'fille de l'air'", 3, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0475000/475146_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Jasmin arceau : d12, h40 cm, 300 boutons", 10, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0695000/695372_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Guzmania: Pot Ø12cm - Coloris variables", 11, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0055000/55548_010.jpg");
INSERT INTO product (name, price, image) 
VALUES("Clivia : plante H.50cm pot", 13, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0210000/210440_005.jpg");
INSERT INTO product (name, price, image) 
VALUES("Saintpaulia : plante Ø12cm petit modèle pot", 5, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0075000/75065_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Azalée d'intérieur : plante Ø15cm pot Ø30cm", 19, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0210000/210434_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Vriéséa: Pot Ø12cm - Coloris variables", 11, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0063000/63155_006.jpg");
INSERT INTO product (name, price, image) 
VALUES("Guzmania : d.13cm", 13, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0751000/751067_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Composition pot zinc - Coloris variables", 35, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0320000/320188_004.jpg");
INSERT INTO product (name, price, image) 
VALUES("Médinilla Magnifica : pot Ø17cm", 21, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0441000/441079_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Euphorbia milii 'Couronne du Christ' : Ø10cm", 11, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0121000/121533_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Anthurium housse kraft : pot Ø12 cm", 11, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0906000/906239_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Médinilla : 3/4 fleurs pot", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0063000/63168_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum 'Sweet Lauretta' cache-pot gris D21cm", 52, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832921_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Strelizia 'Nicolai': pot D 24 cm", 34, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0788000/788875_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum Bingo Cupido cache-pot blanc D17cm", 41, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832829_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Spathiphyllum Bingo Cupido pot D17xH70cm", 38, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832827_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bégonia maculata blanco Pot D14cm", 14, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0873000/873386_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis 2 tiges - pot D.12 cm", 18, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0261000/261303_017.jpg");
INSERT INTO product (name, price, image) 
VALUES("CYMB. 2T D12CM C.POT DOLOMITE-(952439)", 34, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0952000/952439_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis rose en cascade 2 tiges - pot D.13 cm", 27, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0569000/569074_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis en arceau 2 tiges - pot D.12 cm", 31, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0482000/482795_012.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis 1 tige - pot D.6 cm", 8, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0312000/312849_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis 'Kolibri'2 tiges - pot D.9 cm", 13, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0588000/588902_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Dendrobium nobilé 1 tige - pot D.12 cm", 15, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0067000/67544_014.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis, palm tree", 35, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951252_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis, arceau", 33, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951250_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis, arceau", 33, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951253_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Phalaenopsis 'Gold Las Vegas':3 tiges pot D12 cm", 27, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0953000/953486_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis 'Tsarine' 2 tiges - pot D.15 cm", 30, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0504000/504939_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis, spirale", 25, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951251_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Dendrobium nobilé 2 tiges - pot D.12 cm", 18, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0750000/750197_004.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Cambria 1 tige - pot D.11 cm", 14, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0662000/662530_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée paphiopedilum leanum : pot D12x H40cm", 25, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0953000/953485_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Zygopetalum 1 tige - pot D.12 cm", 14, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0504000/504900_004.jpg");
INSERT INTO product (name, price, image) 
VALUES("Quelle orchidée choisir selon sa signification ?", 1, "https://images.truffaut.com/media/catalog/product/v/a/variete-orchidee-2.jpg");
INSERT INTO product (name, price, image) 
VALUES("Entretenir son orchidée pour déclencher la floraison", 1, "https://images.truffaut.com/media/catalog/product/f/l/floraison-orchidee-2_1.jpg");
INSERT INTO product (name, price, image) 
VALUES("Comment préserver votre orchidée des maladies ?", 1, "https://images.truffaut.com/media/catalog/product/m/a/maladie-orchid-e-2.jpg");
INSERT INTO product (name, price, image) 
VALUES("Comment planter l'orchidée ?", 1, "https://images.truffaut.com/media/catalog/product/p/l/planter-orchidee-.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis 'White World' 2 tiges - pot D.13 cm", 19, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0827000/827254_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Quelle variété d'orchidée choisir ?", 1, "https://images.truffaut.com/media/catalog/product/r/d/rd-refleurir_orchidees_banniere.jpgp_1-compressor_1.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée oncidium : entretien et floraison", 1, "https://images.truffaut.com/media/catalog/product/o/r/orchidee-oncidium.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cultiver l'orchidée Sabot de Vénus (paphiopedilum)", 1, "https://images.truffaut.com/media/catalog/product/h/q/hqdefault_4_4.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée zygopetalum : culture et floraison", 1, "https://images.truffaut.com/media/catalog/product/o/r/orchidee-zygopetalum-banniere.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée cambria : culture et floraison", 1, "https://images.truffaut.com/media/catalog/product/h/q/hqdefault_4_3.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée miltonia : entretien et floraison", 1, "https://images.truffaut.com/media/catalog/product/h/q/hqdefault_4_2.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée vanille : entretien et floraison", 1, "https://images.truffaut.com/media/catalog/product/o/r/orchidee_vanille.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée dendrobium : culture et entretien", 1, "https://images.truffaut.com/media/catalog/product/h/q/hqdefault_3_3.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée vanda : culture, entretien et floraison", 1, "https://images.truffaut.com/media/catalog/product/b/l/blue-vanda-banniere.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée cymbidium : culture, entretien et floraison", 1, "https://images.truffaut.com/media/catalog/product/h/q/hqdefault_3_4.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée cattleya : culture et floraison", 1, "https://images.truffaut.com/media/catalog/product/o/r/orchidee-cattleya-banniere.jpg");
INSERT INTO product (name, price, image) 
VALUES("Comment faire refleurir une orchidée ?", 1, "https://images.truffaut.com/media/catalog/product/r/e/refleurir-orchidees-1.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis : culture et entretien", 1, "https://images.truffaut.com/media/catalog/product/o/r/orchid-e_phalaenopsis_1.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Paphiopedilum 1 tige - pot D.12 cm", 32, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0531000/531284_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Dendrobium nobilé 1 tige - en pot", 16, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0261000/261603_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis, spirale", 25, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951254_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis, palm tree", 35, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951249_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis, 3 tiges", 32, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951247_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée phalaenopsis 2 tiges, cascade", 30, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0951000/951242_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("CYMBIDIUM 3H D12 H50-(953484)", 30, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0953000/953484_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée cambria cache-pot céramique Ø14 cm - 2 tiges", 24, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0952000/952435_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis en cascade 2 tiges - pot D.14 cm", 27, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0908000/908930_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis 1 tige - pot D.12 cm", 39, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0908000/908698_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Phalaenopsis varié:4 tiges Truffaut H 60 cm pot D14 cm", 24, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0926000/926694_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Phalaenopsis blanc:4 tiges Truffaut H 60 cm pot D14 cm", 24, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0926000/926693_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Orchidée Phalaeonopsis 'Duetto' 4 tiges - pot D.17 cm", 41, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910885_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Zeylanica : pot D17 x H60cm", 41, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832797_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes : Pot d5.5cm - Variétés variables", 2, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0628000/628685_027.jpg");
INSERT INTO product (name, price, image) 
VALUES("Schlumbergera: Pot D 13 cm", 8, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0693000/693107_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Zeylanica : cache- pot D21cm", 58, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910698_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Zeylanica : cache- pot blanc D21cm", 58, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832856_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes variées : Pot D5.5cm Lot de 20", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670298_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sanseveria cylindrica : cache-pot gris D17cm", 54, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832813_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sanseveria cylindrica : D17xH55cm", 49, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832812_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Zeylanica : pot D21 x H70cm", 52, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832854_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Valise découverte des Succulentes", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0926000/926982_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Zeylanica : cache- pot sable D17cm", 45, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910731_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Zeylanica : cache- pot blanc D17cm", 45, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832799_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Zeylanica : cache- pot gris D17cm", 45, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832798_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("20 mini succulentes + seaux zinc blancs", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0753000/753231_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("20 mini succulentes + seaux zinc couleur naturelle", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0753000/753229_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes variées : Pot D8cm Lot de 20", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670301_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Népenthès : pot Ø9cm", 6, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0318000/318568_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("12 mini succulentes + Pots terre cuite", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0753000/753234_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Laurentii avec cache-pot en céramique blanc - 15cm ", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0804000/804253_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes variées : Pot D8cm Lot de 10", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670300_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Collection d’Haworthia : Pot D5.5cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670315_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes Mexicaines : Pot D5.5cm Lot de 10", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670304_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes variées : Pot D8cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670302_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sansevieria Laurentii pot ⌀12 cm - H.30-40cm - Lot de 2", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1023000/1023074_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("5 mini succulentes + seaux zinc blancs", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0753000/753232_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("5 mini succulentes + seaux zinc couleur naturelle", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0753000/753230_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Aloë Vera d'intérieur pot ⌀12 cm - H.20 - 30 cm - Lot de 2", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1023000/1023070_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Collection d’Aeonium: Pot D5.5cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670319_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes Mexicaines hybrides : Pot D5.5cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670307_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes variées : Pot D5.5cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670299_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Collection de Sedum Mexicains : Pot D5.5cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670317_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Collection de Crassula: Pot D5.5cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670311_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Collection d’Echeveria : Pot D5.5cm Lot de 5", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670309_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Collection d’Aeonium : Pot D8cm Lot de 3", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670320_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes Mexicaines hybrides : Pot D8cm Lot de 3", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670308_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Collection de Sedum Mexicains : Pot D8cm Lot de 3", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0670000/670318_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("3 mini succulentes + Pots terre cuite", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0753000/753233_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Euphorbe spinanera pot D21cm", 60, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0718000/718750_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cactus de Noël : Ø11cm, pot", 6, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0128000/128842_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cactus: d8.5cm - Variétés variables", 5, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0628000/628683_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cactus:pot D5,5 cm - Variétés variables", 2, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0565000/565111_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Aloès Véra: Plante Ø15cm pot", 15, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0326000/326095_009.jpg");
INSERT INTO product (name, price, image) 
VALUES("Aloès Véra : Conteneur de diamètre 12 cm", 9, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0462000/462944_007.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cactus:pot D7 cm - Variétés variables", 6, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0063000/63228_006.jpg");
INSERT INTO product (name, price, image) 
VALUES("Attrape-mouches : Ø7cm, pot", 6, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0085000/85267_006.jpg");
INSERT INTO product (name, price, image) 
VALUES("Euphorbe : plante Ø23cm pot", 64, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0349000/349053_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Succulentes : Pot d7cm - Variétés variables", 6, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0718000/718726_009.jpg");
INSERT INTO product (name, price, image) 
VALUES("Sarracénia : plante Ø8cm pot", 7, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0030000/30875_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï d'intérieur 5 ans, pot déco orient", 29, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832717_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("BonsaÏ d'extérieur avec soucoupe 7ans", 44, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910626_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Azalée bonsaï : conseils et entretien", 1, "https://images.truffaut.com/media/catalog/product/a/z/azalee-bonsai2.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï carmona : entretien et taille", 1, "https://images.truffaut.com/media/catalog/product/2/-/2-bonsai-carmona.jpg");
INSERT INTO product (name, price, image) 
VALUES("Culture du bonsaï sapin (podocarpus macrophyllus)", 1, "https://images.truffaut.com/media/catalog/product/p/o/podocarpus-2.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cultiver le bonsaï duranta (vanillier de Cayenne)", 1, "https://images.truffaut.com/media/catalog/product/b/o/bonsais2.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï poivrier : rempotage, entretien et taille", 1, "https://images.truffaut.com/media/catalog/product/b/o/bonsai-poivrier-en-pot.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï ficus : rempotage, entretien et taille", 1, "https://images.truffaut.com/media/catalog/product/f/i/ficus-bonsai-banni-re.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Buxus 20 ans", 350, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832635_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï : espèces, entretien et taille", 1, "https://images.truffaut.com/media/catalog/product/b/o/bonsai-banniere.jpg");
INSERT INTO product (name, price, image) 
VALUES("Set de 2 Papyrus Cyperus - pot ⌀14cm - H.50-60cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028991_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Assorti de 3 Citrus - pot ⌀9 cm - H.25-40cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028959_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Set Bonsaï et cascade-pierres - support l.30cm- H.25-30cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028951_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Set Bonsaï et cascade-Buddha - support l.30cm- H.25-30cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028950_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Set de 2 Bonsaï Ficus Ginseng - pot ⌀15 cm - H.35-45cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028949_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï japonnais tige en S - pot ⌀19 cm - H.60-80 cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028948_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï d'intérieur 8 ans, pot déco nature", 57, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832728_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï d'intérieur 8 ans, pot déco", 57, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832726_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï d'intérieur 6 ans, pot déco art", 36, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832723_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï d'intérieur 6 ans, pot déco orient", 36, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832721_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï d'intérieur 5 ans, pot déco", 29, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832718_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Eugenia uniflora 10/12 ans", 67, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0927000/927584_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Ficus 25/30 ans + soucoupe", 215, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0906000/906247_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Forêt Acer palmatum 'Atropurpureum' 8/9 d'âge", 35, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0828000/828654_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Acer palmatum 'Atropurpureum' 8/9 d'âge", 35, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0828000/828653_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Mix bonsaï 6/8ans avec soucoupe", 38, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0827000/827029_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Indonésien 19 ans soucoupe", 305, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0828000/828003_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Azalée: 7-9 ans étage", 39, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473744_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Azalée: 5-6 ans étage", 24, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473743_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Buxus:5-6 ans boule", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473733_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Myrte:4-5 ans", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473722_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Myrte:3-4 ans", 9, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473721_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Portulacaria:13-14 ans étage", 115, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473686_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Portulacaria:10-12 ans étage", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473685_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Portulacaria:7-9 ans étage", 36, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473684_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Portulacaria:7-9 ans boule", 29, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473683_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Portulacaria:5-6 ans boule", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473682_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Podocarpus : 5-6 ans", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0712000/712271_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Orme de Chine : 3-4 ans", 9, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0712000/712269_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Ligustrum panaché: 5/6 ans", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0650000/650869_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Poivrier :13-14 ans étage", 115, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0547000/547354_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Poivrier :7-9 ans boule", 34, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0509000/509822_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Poivrier :20/25 ans avec soucoupe", 189, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473729_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Poivrier :10-12 ans étage", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473727_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Poivrier :5-6 ans boule", 22, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473725_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Poivrier :5-6 ans étage", 24, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473724_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Ligustrum: 13-14 ans étage", 109, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473710_005.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bonsaï Ligustrum: 10-12 ans étage", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0473000/473709_005.jpg");
INSERT INTO product (name, price, image) 
VALUES("Chamaedora (palmier nain) pot D24cm", 89, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910670_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dieffenbachia Maroba - Cache Pot Blanc D.21 - H.80", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801437_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : pot D24cm", 99, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910671_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Yucca 3 cannes - 130cm : D.24", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801454_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Pachira Aquatica :cache- pot blanc D21cm", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832886_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Ficus Benjamina Danielle : H100/110cm, D20cm", 29, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0475000/475397_003.jpg");
INSERT INTO product (name, price, image) 
VALUES("Pachira Aquatica :cache- pot gris D21cm", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832885_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dieffenbachia Maroba - Cache Pot Anthracite : D.21 - H.80", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801438_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Tableau végétal stabilisé JI IRUI 140*40", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0956000/956016_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Monstera Deliciosa pot D30cm", 109, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910696_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Philodendron Xanadu pot D27cm", 109, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910682_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Ficus binnendijkii 'Alii' cache-pot blanc D21cm", 53, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832871_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Beaucarnea Recurvata Cache-pot Anthracite : D.21 - H.60", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801444_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Chamaedora (palmier nain) pot déco clair D24cm", 99, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910737_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Beaucarnea : pot D27cm", 99, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910680_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dracanea Marginata CP Blanc : D.21-H.105", 49, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801459_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Tableau végétal stabilisé HANAKOTOBA XL 140*40 cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0956000/956015_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier Kentia pot ⌀19 cm - H. 80-90cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1023000/1023051_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Tableau végétal gamme nature rectangle XL - 60x100cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0646000/646556_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Ficus Benjamina Danielle : D.17-H.60", 42, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801461_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Beaucarnea Ramifié : D.23 - H.70", 79, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801456_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dracanea Marginata 3 pieds : D.21-H.105", 39, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801458_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dracanea Lemon Lime CP Anthracite : D.21-H.100", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801447_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Monstera Deliciosa - Cache-pot Anthracite : D.21 - H70", 54, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801432_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dieffenbachia Maroba : D.21 - H.80", 52, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801436_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Tradescantia Nanouk' : d.12cm", 8, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0789000/789670_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dracaena Janet Craig cache-pot gris D21cm", 69, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832897_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Alocasia gageana 'california' pot D21cm", 64, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910677_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Zamioculcas Cache-Pot Blanc : D.21 - H.90", 64, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801440_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dracaena Janet Craig pot D21 x H100cm", 63, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832896_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Areca - H. 110.0 : D.21.0", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801433_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : cache-pot sable D19cm", 55, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910724_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Ficus benjamina Anastasia pot D21 x H105cm", 55, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832872_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bananier Cavendish' : cache-pot blanc D21cm", 55, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832880_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : cache-pot blanc D19cm", 55, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832844_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Ficus Scyasthipula CP Ant. : D.21-H100", 54, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801453_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Monstera Deliciosa - Cache-pot Blanc : D.21 - H.70", 54, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801431_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Yucca 2 têtes 60-30 : cache-pot gris D.21cm", 54, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910759_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Pachira Aquatica : pot D21 x H90cm", 53, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832884_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Ficus benjamina 'Twilight' cache-pot gris D21cm", 53, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832861_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Assortiment de 4 plantes résistantes - pot ⌀12 cm - H.30 - 40 cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1023000/1023076_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : pot D19 x H80cm", 52, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832842_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Zamioculcas : D.21 - H.90", 51, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801439_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Schefflera : H40/60 cm - Variétés variables", 11, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0482000/482813_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Beaucarnea : Cache-pot blanc D17cm", 49, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832805_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Bananier Musa acuminata Dwarf Cavendish : D21 x H90cm", 49, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832878_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Ficus Lyrata : D.21 H.85", 49, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801424_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Dracanea Marginata CP Ant. : D.21-H.105", 49, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801460_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Chamaedora (palmier nain) pot D24cm", 89, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910670_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : pot D24cm", 99, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910671_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Rhapis : pot déco clair D24cm", 119, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910741_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Chamaedora (palmier nain) pot déco clair D24cm", 99, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910737_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier Kentia pot ⌀19 cm - H. 80-90cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1023000/1023051_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Areca - H. 110.0 : D.21.0", 59, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801433_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : cache-pot sable D19cm", 55, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910724_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : cache-pot blanc D19cm", 55, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832844_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : pot D19 x H80cm", 52, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832842_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmiers Areca d'intérieur - pot ⌀17 cm - H.60-70 cm - Lot de 2", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1023000/1023075_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia: H.90/100cm, D.17cm,", 47, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0506000/506230_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier nain: pot d.17 cm h.40/60cm", 11, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0020000/20899_009.jpg");
INSERT INTO product (name, price, image) 
VALUES("Areca - Cache-pot Anthracite : D.21.0", 69, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801435_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Livistona : pot déco D19xH65cm. Avec noix.", 28, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0788000/788834_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier nain : H.30/40cm pot", 6, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0020000/20893_007.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : cache-pot gris D19cm", 55, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832843_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Rhapis :cache-pot blanc D21cm", 93, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832907_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Faux dattier : H.100cm pot", 75, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0292000/292649_005.jpg");
INSERT INTO product (name, price, image) 
VALUES("Areca - Cache-pot Blanc : D.21.0", 69, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0801000/801434_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier hawaïen : rempotage, arrosage et entretien", 1, "https://images.truffaut.com/media/catalog/product/2/-/2-palmier-hawa-en.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier livistona : espèces et entretien", 1, "https://images.truffaut.com/media/catalog/product/2/-/2-palmier-livistona.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cultiver le phoenix roebelenii (ou palmier dattier)", 1, "https://images.truffaut.com/media/catalog/product/c/u/cultiver-palmier-dattier2.jpg");
INSERT INTO product (name, price, image) 
VALUES("Rhapis : pot déco foncé D24cm", 119, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910742_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Chamaedora (palmier nain) pot déco foncé D24cm", 99, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910738_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Rhapis : pot D24cm", 109, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910673_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier nain Chamaedora : espèces et culture ", 1, "https://images.truffaut.com/media/catalog/product/p/a/palmier-interieur-nain.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cocotier : plantation et entretien", 1, "https://images.truffaut.com/media/catalog/product/c/o/cocotier_plante_interieur_banniere.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier Aréca : plantation et entretien", 1, "https://images.truffaut.com/media/catalog/product/p/a/palmier-interieur.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia : rempotage, arrosage et entretien", 1, "https://images.truffaut.com/media/catalog/product/k/e/kentia-palmier.jpg");
INSERT INTO product (name, price, image) 
VALUES("Rhapis :cache-pot gris D21cm", 93, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832906_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Rhapis : pot D21 x H80cm", 87, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832905_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Comment entretenir un palmier d'intérieur ? ", 1, "https://images.truffaut.com/media/catalog/product/e/n/entretenir-palmier-interieur.jpg");
INSERT INTO product (name, price, image) 
VALUES("Quelle variété de palmier d’intérieur choisir ? ", 1, "https://images.truffaut.com/media/catalog/product/p/a/palmier-interieur-1.jpg");
INSERT INTO product (name, price, image) 
VALUES("Set de 2 Papyrus Cyperus - pot ⌀14cm - H.50-60cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028991_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Set de 2 Palmiers Areca - pot ⌀21cm - H.100-120cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028971_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier Areca Dyspis Lutescens - pot ⌀21cm - H.100-120cm", 0, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/1028000/1028970_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Kentia pot Ø34 cm", 299, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0953000/953552_005.jpg");
INSERT INTO product (name, price, image) 
VALUES("Caryota mitis:H 110 cm pot D10 cm", 45, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0953000/953548_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Livistona rotundifolia, cache-pot céramique Ø14 cm", 16, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0952000/952436_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Livistona rotundifolia pot D17cm", 16, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0908000/908716_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Palmier, Caryota Mitis H170cm", 106, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0909000/909257_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Areca en vannerie D23cm", 44, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0909000/909162_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Areca - Cache-pot sable : D.21cm", 69, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910713_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Rhapis :cache-pot sable D21cm", 93, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910708_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cycas revoluta : cache-pot sable D21cm", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0910000/910706_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Livistona chinensis:H100 cm pot D24 cm", 57, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0873000/873305_002.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cycas revoluta : cache-pot blanc D21cm", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832901_001.jpg");
INSERT INTO product (name, price, image) 
VALUES("Cycas revoluta : cache-pot gris D21cm", 74, "https://images.truffaut.com/media/catalog/product/cdn:///Articles/jpg/0832000/832900_001.jpg");
