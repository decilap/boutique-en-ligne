 // convert Shop_Only2100.json to sql script
var fs = require('fs');
var format = require('string-format')
// create write stream
var ofs = fs.createWriteStream("./Shop.sql");
 


var ShopJson = JSON.parse(fs.readFileSync("flowers.json"));
generateSqlProduct(ShopJson);

function generateSqlProduct(data){
    ShopJson['flowers'].forEach(function(flower) {
ofs.write(
format(`INSERT INTO product (name, price, image) 
VALUES("{product_name}", ${parseInt(flower.product_price)}, "{product_url_picture}");\n`, flower)
);
    }, this); 
}
